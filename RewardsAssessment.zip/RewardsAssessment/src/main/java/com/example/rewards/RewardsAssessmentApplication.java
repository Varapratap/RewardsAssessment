package com.example.rewards;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RewardsAssessmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(RewardsAssessmentApplication.class, args);
		System.out.println("Rewards Assessment");
	}

}
