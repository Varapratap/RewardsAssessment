package com.example.rewards.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.example.rewards.model.Customer;
import com.example.rewards.model.MyTransaction;
import com.example.rewards.repository.RewardsMock;
import com.example.rewards.repository.RewardsService;



@RestController
@RequestMapping("/test")
public class RewardsController {

	@Autowired
	private RewardsMock rewardsService1;
		
	@Autowired
	private RewardsService rewardsService;
	
	@GetMapping("/{custId}/reward")
 	public List<MyTransaction> getAll(@PathVariable Integer custId) {
    return rewardsService1.getAll();
    }
	
	
	@GetMapping("/customers")
	public List<Customer> findCustomerAll() {
		return rewardsService.getCustomerAll();
	}
	
	@GetMapping("/customers/{id}")
	public ResponseEntity<Customer> getCustomer(@PathVariable Integer id) {
		Customer customer = rewardsService.getCustomerById(id);
		if (customer == null) return new ResponseEntity<Customer>(HttpStatus.NOT_FOUND);
		return new ResponseEntity<Customer>(customer, HttpStatus.OK);
	}
	
	
}
