package com.example.rewards.repository;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Service;

import com.example.rewards.model.Customer;
import com.example.rewards.model.MyTransaction;

@Service
public class RewardsMock {

	private static List<MyTransaction> transactions = new ArrayList<MyTransaction>();
	private static long index;
	
	static {
		
		transactions.add( new MyTransaction(index++, new Customer(1, "Vara"), 50.0, "Purchase_1", new Date()) );
		transactions.add( new MyTransaction(index++, new Customer(2, "Pratap"), 100.0, "Purchase_2", new Date()) );
		transactions.add( new MyTransaction(index++, new Customer(3, "Raj"), 120.0, "Purchase_3", new Date()) );	
	}	
	
	public List<MyTransaction> getAll() {
		return transactions;
	}
	
}
